var group__elem__type__gr =
[
    [ "dimElementGroup", "group__dim_element_group__gr.html", null ],
    [ "registerPropertiesGroup", "group__register_properties_group__gr.html", null ]
];